use sbs;
select * from maintain,maintain_consume,record where eid=1;

select * from equipemnt where to_days(now())-to_days(eremaintain)>=cycle-1;